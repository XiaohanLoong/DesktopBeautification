#!/bin/bash

sleep 4
conky -c $HOME/.Conky/future_conky/conkyrc &
exit 0

