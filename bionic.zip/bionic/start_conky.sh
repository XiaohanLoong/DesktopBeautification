#!/bin/bash

sleep 15
conky -c ~/.Conky/bionic/config/conkyrc &
exit 0
