#!/bin/bash

sleep 30
conky -c ~/.Conky/octacore/config/conkyrc1 &
sleep 1
conky -c ~/.Conky/octacore/config/conkyrc2 &
sleep 1
conky -c ~/.Conky/octacore/config/conkyrc3 &
sleep 1
conky -c ~/.Conky/octacore/config/conkyrc4 &
sleep 1
conky -c ~/.Conky/octacore/config/conkyrc5 &
sleep 1
conky -c ~/.Conky/octacore/config/conkyrc6 &
sleep 1
conky -c ~/.Conky/octacore/config/conkyrc7 &
sleep 1
conky -c ~/.Conky/octacore/config/conkyrc8 &
sleep 1
conky -c ~/.Conky/octacore/config/conkyrc9 &
exit 0
