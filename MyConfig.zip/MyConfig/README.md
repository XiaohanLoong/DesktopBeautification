# MyConfig
> 保存我的系统配置。包括zsh配置，zsh历史记录，conky配置，vim配置，idea配置，pycharm配置，android-studio配置，eclipse配置。
