#!/bin/bash



killall conky
conky -c ~/.conky/Metro/conky.conf.11 -x 30 -y 320 -p 10
conky -c ~/.conky/Metro/conky.conf.21 -x 30 -y 200 -p 1


conky -c ~/.conky/Metro/conky.conf.12 -x 290 -y 200 -p 1
conky -c ~/.conky/Metro/conky.conf.13 -x 550 -y 320 -p 1
conky -c ~/.conky/Metro/conky.conf.23 -x 550 -y 193 -p 1
conky -c ~/.conky/Metro/conky.conf.14 -x 810 -y 280 -p 1
conky -c ~/.conky/Metro/conky.conf.24 -x 810 -y 200 -p 1
conky -c ~/.conky/Metro/conky.conf.25 -x 1070 -y 200 -p 1
